// KillWormDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "KillWorm.h"
#include "KillWormDlg.h"
#include "ScanEngine.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// ����Ӧ�ó��򡰹��ڡ��˵���� CAboutDlg �Ի���

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// �Ի�������
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

// ʵ��
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CKillWormDlg �Ի���




CKillWormDlg::CKillWormDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CKillWormDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_dwWormFileCount = 0;
}

void CKillWormDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST_RESULT, m_ListResult);
}

BEGIN_MESSAGE_MAP(CKillWormDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BT_SCAN, &CKillWormDlg::OnBnClickedBtScan)
	ON_BN_CLICKED(IDC_BUTTON_KILL, &CKillWormDlg::OnBnClickedButtonKill)
END_MESSAGE_MAP()


// CKillWormDlg ��Ϣ��������

BOOL CKillWormDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// ��������...���˵������ӵ�ϵͳ�˵��С�

	// IDM_ABOUTBOX ������ϵͳ���Χ�ڡ�
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// ���ô˶Ի����ͼ�ꡣ��Ӧ�ó��������ڲ��ǶԻ���ʱ����ܽ��Զ�
	//  ִ�д˲���
	SetIcon(m_hIcon, TRUE);			// ���ô�ͼ��
	SetIcon(m_hIcon, FALSE);		// ����Сͼ��

	// TODO: �ڴ����Ӷ���ĳ�ʼ������

	return TRUE;  // ���ǽ��������õ��ؼ������򷵻� TRUE
}

void CKillWormDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// �����Ի���������С����ť������Ҫ����Ĵ���
//  �����Ƹ�ͼ�ꡣ����ʹ���ĵ�/��ͼģ�͵� MFC Ӧ�ó���
//  �⽫�ɿ���Զ���ɡ�

void CKillWormDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // ���ڻ��Ƶ��豸������

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// ʹͼ���ڹ��������о���
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// ����ͼ��
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

//���û��϶���С������ʱϵͳ���ô˺���ȡ�ù����ʾ��
//
HCURSOR CKillWormDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

// ɨ�財��
void CKillWormDlg::OnBnClickedBtScan()
{
	DWORD dwThreadID = 0;
	HANDLE hThread = NULL;
	LPITEMIDLIST lpDist = NULL;
	char cBuffer[MAX_PATH] = {0x0};
	BROWSEINFO tBI;
	tBI.hwndOwner = NULL;
	tBI.lpszTitle = "ѡ����Ҫɨ���Ŀ¼";
	tBI.pszDisplayName = cBuffer;
	tBI.ulFlags = BIF_EDITBOX;
	tBI.pidlRoot = NULL;
	tBI.lParam = 0;
	tBI.lpfn = NULL;

	lpDist = SHBrowseForFolder(&tBI);
	if (lpDist != NULL)
	{
		SHGetPathFromIDList(lpDist, cBuffer);
		m_szScanDir = cBuffer;
		if (m_szScanDir.Right(1) != "\\")
		{
			m_szScanDir = m_szScanDir + "\\";
		}
		GetDlgItem(IDC_EDIT_PATH)->SetWindowText(m_szScanDir);
	}

	hThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)ScanThreadProc, (LPVOID)this, 0, &dwThreadID);
//	WaitForSingleObject(hThread, INFINITE);
	CloseHandle(hThread);
}

void CKillWormDlg::OnBnClickedButtonKill()
{

	DWORD dwThreadID = 0;
	HANDLE hThread = NULL;

	hThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)KillThreadProc, (LPVOID)this, 0, &dwThreadID);
	CloseHandle(hThread);
}

void CKillWormDlg::FindFile(LPCTSTR lpPath)
{
	WIN32_FIND_DATA sFindData;
	HANDLE hFindFile = NULL;
	string szPath = lpPath;
	string szFile = "";
	string szTemp = "";
	CString szCheckFile = "";
	CString szEXE = "";
	string szTemp2 = "";


	szPath = szPath + "*.*";
	hFindFile = FindFirstFile(szPath.c_str(), &sFindData);
	do 
	{
		szFile = sFindData.cFileName;
		if (szFile != "." && szFile != "..")
		{
			if (sFindData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
			{
				szTemp = lpPath + szFile;
				szTemp = szTemp + "\\";

				FindFile(szTemp.c_str());
			}
			else
			{
				szTemp2 = lpPath + szFile;
				szCheckFile = szFile.c_str();
				szEXE = szCheckFile.Right(szCheckFile.GetLength() - szCheckFile.ReverseFind('.') - 1);
				szEXE.MakeUpper();
				if (szEXE == "EXE")
				{
					if (CheckWormFile(szTemp2.c_str()))
					{
						m_vWormFile.push_back(lpPath + szFile);
						m_dwWormFileCount++;
					}
				}
			}
		}

	} while (FindNextFile(hFindFile, &sFindData));
//	CloseHandle(hFindFile);
}

BOOL CKillWormDlg::CheckWormFile(const char* lpPathFile)
{
	CString szPathFile = "��������ļ�->";
	CScanEngine objSE;
	LPVOID lpBaseAddress = NULL;
	LPVOID lpNtHeader = NULL;

	SetWindowText(lpPathFile);
	lpBaseAddress = objSE.OpenFile(lpPathFile);
	if (lpBaseAddress != NULL)
	{
		lpNtHeader = objSE.GetNtHeader(lpBaseAddress);
		if (objSE.IsPEFile(lpBaseAddress))
		{
			if (objSE.IsWorm(lpNtHeader))
			{
				szPathFile = szPathFile + lpPathFile;
				m_ListResult.AddString(szPathFile);
				szPathFile = "��������ļ�->";
				objSE.CloseFile(lpBaseAddress);
				return TRUE;
			}
		}
	}
	objSE.CloseFile(lpBaseAddress);

	return FALSE;
}

DWORD CKillWormDlg::ScanThreadProc(LPVOID LPARAM)
{
	CKillWormDlg* pObjKillWormDlg = (CKillWormDlg*)LPARAM;
	// ���vector�����е�����
	pObjKillWormDlg->m_vWormFile.clear();
	pObjKillWormDlg->m_ListResult.ResetContent();
	if (pObjKillWormDlg->m_szScanDir.IsEmpty())
		return 0;

	pObjKillWormDlg->FindFile(pObjKillWormDlg->m_szScanDir);

// 	for (vector<string>::iterator vFile = pObjKillWormDlg->m_vWormFile.begin(); vFile != pObjKillWormDlg->m_vWormFile.end(); vFile++)
// 	{
// 		pObjKillWormDlg->CheckWormFile(vFile->c_str());
// 	}
	CString szScanCount = "";
	szScanCount.Format("ɨ����ϣ���ɨ����%d������ļ���", pObjKillWormDlg->m_dwWormFileCount);
	pObjKillWormDlg->SetWindowText(szScanCount);
	pObjKillWormDlg->m_ListResult.AddString(szScanCount);
	return 0;
}


DWORD CKillWormDlg::KillThreadProc(LPVOID LPARAM)
{
	CKillWormDlg* pObjKillWormDlg = (CKillWormDlg*)LPARAM;
	CScanEngine objSE;
	LPVOID lpBaseAddress = NULL;
	LPVOID lpNtHeader = NULL;
	CString szResult = "";
	DWORD dwCount = 0;
	CString szClearCount = "";

	pObjKillWormDlg->m_ListResult.ResetContent();

	for (vector<string>::iterator vFile = pObjKillWormDlg->m_vWormFile.begin(); vFile != pObjKillWormDlg->m_vWormFile.end(); vFile++)
	{
		lpBaseAddress = objSE.OpenFile(vFile->c_str());
		lpNtHeader = objSE.GetNtHeader(lpBaseAddress);
		if (objSE.Kill(lpNtHeader))
		{
			szResult.Format("�������ļ�->%s", vFile->c_str());
			pObjKillWormDlg->m_ListResult.AddString(szResult);
			szResult = "";
			dwCount++;
		}
		objSE.CloseFile(lpBaseAddress);
	}
	pObjKillWormDlg->m_vWormFile.clear();
	szClearCount.Format("�����ϣ����������ļ�%d����", dwCount);
	pObjKillWormDlg->SetWindowText(szClearCount);
	pObjKillWormDlg->m_ListResult.AddString(szClearCount);

	return 0;
}
