// KillWormDlg.h : ͷ�ļ�
//

#pragma once
#include "afxwin.h"
#include <string>
#include <vector>

using namespace std;


// CKillWormDlg �Ի���
class CKillWormDlg : public CDialog
{
// ����
public:
	CKillWormDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_KILLWORM_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON m_hIcon;
	CString m_szScanDir;
	DWORD m_dwWormFileCount;
	vector<string> m_vWormFile;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
	CListBox m_ListResult;

private:
	static DWORD WINAPI ScanThreadProc(LPVOID LPARAM);	// ɨ���̺߳���
	static DWORD WINAPI KillThreadProc(LPVOID LPARAM);	// �ɵ�����̺߳���
	void FindFile(LPCTSTR lpPath);
	BOOL CheckWormFile(const char* lpPathFile);

public:
	afx_msg void OnBnClickedBtScan();
public:
	afx_msg void OnBnClickedButtonKill();
};
