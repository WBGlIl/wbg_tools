#pragma once
#include <assert.h>


#define MAP_NAME	"KillWorm"
#define WORM_FLAG	".text"
#define WORM_ENTER_POINT_ADDRESS_OFFS	0x62		// ԭ��ڵ�ֵ��ƫ��

class CScanEngine
{
public:
	CScanEngine(void);
public:
	~CScanEngine(void);

private:
	HANDLE m_hFile;			// �ļ����
	HANDLE m_hMap;			// ӳ���ļ��ľ��
	LPVOID m_lpBaseAddress;	// ָ�������ļ��Ŀ�ʼλ��
	DWORD  m_dwWorm_RawDataSize;	// ��没�����εĴ�С
	unsigned char start[35] =
	{
	  0x55, 0x8B, 0xEC, 0x81, 0xEC, 0x6C, 0x01, 0x00, 0x00, 0x33,
	  0xC0, 0x53, 0x56, 0x57, 0x89, 0x45, 0xDC, 0x89, 0x45, 0xF0,
	  0x89, 0x45, 0xEC, 0x89, 0x45, 0xF8, 0x89, 0x45, 0xF4, 0x89,
	  0x45, 0xE0, 0x89, 0x45, 0xE8
	};

private:
	PIMAGE_DOS_HEADER GetDosHeader(LPVOID lpBaseAddress);
// 	PIMAGE_FILE_HEADER GetFileHeader(LPVOID lpNtAddress);
// 	PIMAGE_OPTIONAL_HEADER GetOpHeader(LPVOID lpNtAddress);
	PIMAGE_SECTION_HEADER GetSectionHeader(LPVOID lpNtAddress);
	DWORD Align(DWORD nSize, DWORD nAlignMent);

public:
	LPVOID OpenFile(const char* pFileName);
	void CloseFile(LPVOID lpBaseAddress);
	PIMAGE_NT_HEADERS GetNtHeader(LPVOID lpBaseAddress);
	bool IsPEFile(LPVOID lpBaseAddress);
	bool IsWorm(LPVOID lpNtHeader);
	bool Kill(LPVOID lpNtHeader);
};
