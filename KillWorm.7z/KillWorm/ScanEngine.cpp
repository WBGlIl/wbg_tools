#include "StdAfx.h"
#include "ScanEngine.h"
#include <string>

using namespace std;

CScanEngine::CScanEngine(void)
{
	m_hFile = NULL;
	m_hMap = NULL;
	m_lpBaseAddress = NULL;
	m_dwWorm_RawDataSize = 0;
}

CScanEngine::~CScanEngine(void)
{
}

LPVOID CScanEngine::OpenFile(const char* pFileName)
{
	DWORD dwErr = 0;
	m_hFile = CreateFile(pFileName, GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if (m_hFile == INVALID_HANDLE_VALUE)
	{
		dwErr = GetLastError();
//		::MessageBox(AfxGetMainWnd()->GetSafeHwnd(), "CreateFile() Error!", "Error", MB_OK | MB_ICONERROR);
		TRACE("CreateFile() Error!");
		return NULL;
	}

	m_hMap = CreateFileMapping(m_hFile, NULL, PAGE_READWRITE, NULL, NULL, MAP_NAME);
	if (m_hMap == INVALID_HANDLE_VALUE)
	{
		dwErr = GetLastError();
//		::MessageBox(AfxGetMainWnd()->GetSafeHwnd(), "CreateFileMaping() Error!", "Error", MB_OK | MB_ICONERROR);
		TRACE("CreateFileMaping() Error!");
		return NULL;
	}

	m_lpBaseAddress = MapViewOfFile(m_hMap, FILE_MAP_ALL_ACCESS, 0, 0, 0);
	if (m_lpBaseAddress == NULL)
	{
		dwErr = GetLastError();
//		::MessageBox(AfxGetMainWnd()->GetSafeHwnd(), "MapViewOfFile() Error!", "Error", MB_OK | MB_ICONERROR);
		TRACE("MapViewOfFile() Error!");
		return NULL;
	}

	return m_lpBaseAddress;
}

void CScanEngine::CloseFile(LPVOID lpBaseAddress)
{
	__try
	{
		FlushViewOfFile(lpBaseAddress, 0);
		if (lpBaseAddress != NULL)
		{
			UnmapViewOfFile(lpBaseAddress);
		}
		if (m_hMap != NULL)
		{
			CloseHandle(m_hMap);
		}
		// �����ļ�ָ��
		DWORD dwFileSize = GetFileSize(m_hFile, NULL);
		if (SetFilePointer(m_hFile, dwFileSize - m_dwWorm_RawDataSize, 0, FILE_BEGIN) == INVALID_SET_FILE_POINTER)
		{
			TRACE("SetFilePoint() Error!");
			return;
		}
		// �����ļ�����
		if (!SetEndOfFile(m_hFile))
		{
			TRACE("SetEndOfFile() Error!");
			return;
		}
	}
	__finally
	{
		if (m_hFile != NULL)
		{
			CloseHandle(m_hFile);
		}
	}
}

PIMAGE_DOS_HEADER CScanEngine::GetDosHeader(LPVOID lpBaseAddress)
{
	PIMAGE_DOS_HEADER pDosHander = NULL;

	pDosHander = (PIMAGE_DOS_HEADER)lpBaseAddress;
	return pDosHander;
}

PIMAGE_NT_HEADERS CScanEngine::GetNtHeader(LPVOID lpBaseAddress)
{
	PIMAGE_DOS_HEADER pDosHeader = (PIMAGE_DOS_HEADER)lpBaseAddress;
	PIMAGE_NT_HEADERS pNtHeader = NULL;

	pNtHeader = (PIMAGE_NT_HEADERS)((BYTE*)pDosHeader + pDosHeader->e_lfanew);
	return pNtHeader;
}

// PIMAGE_FILE_HEADER CScanEngine::GetFileHeader(LPVOID lpNtAddress)
// {
// 	PIMAGE_NT_HEADERS pNtHeader = (PIMAGE_NT_HEADERS)lpNtAddress;
// 	PIMAGE_FILE_HEADER pFileHeader = NULL;
// 
// 	pFileHeader = &pNtHeader->FileHeader;
// 	return pFileHeader;
// }
// 
// PIMAGE_OPTIONAL_HEADER CScanEngine::GetOpHeader(LPVOID lpNtAddress)
// {
// 	PIMAGE_NT_HEADERS pNtHeader = (PIMAGE_NT_HEADERS)lpNtAddress;
// 	PIMAGE_OPTIONAL_HEADER pOpHeader = NULL;
// 
// 	pOpHeader = &pNtHeader->OptionalHeader;
// 	return pOpHeader;
// }

PIMAGE_SECTION_HEADER CScanEngine::GetSectionHeader(LPVOID lpNtAddress)
{
	PIMAGE_NT_HEADERS pNtHeader = (PIMAGE_NT_HEADERS)lpNtAddress;
	PIMAGE_SECTION_HEADER pSectionHeader = NULL;

	pSectionHeader = (PIMAGE_SECTION_HEADER)((BYTE*)pNtHeader + sizeof(IMAGE_NT_HEADERS));
	return pSectionHeader;
}

DWORD CScanEngine::Align(DWORD nSize, DWORD nAlignMent)
{
	DWORD ret = 0, result = 0;
	assert( 0 != nAlignMent); 
	result = nSize % nAlignMent;
	result != 0 ? ret = ((nSize / nAlignMent) + 1) * nAlignMent : ret = nSize;
	return ret;
}

//////////////////////////////////////////////////////////////////////////

bool CScanEngine::IsPEFile(LPVOID lpBaseAddress)
{
	PIMAGE_DOS_HEADER pDosHander = NULL;
	PIMAGE_NT_HEADERS pNtHander = NULL;

	__try
	{
		pDosHander = (PIMAGE_DOS_HEADER)lpBaseAddress;
		pNtHander = GetNtHeader(lpBaseAddress);
		if (pDosHander->e_magic == IMAGE_DOS_SIGNATURE && pNtHander->Signature == IMAGE_NT_SIGNATURE)
		{
			return true;
		}
	}
	__except(1)
	{
		return false;
	}
	return false;
}

bool CScanEngine::IsWorm(LPVOID lpNtHeader)
{
	DWORD dwSectionCount = 0;
	PIMAGE_NT_HEADERS pNtHeader = (PIMAGE_NT_HEADERS)lpNtHeader;
	DWORD dwOldEnterPoint = pNtHeader->OptionalHeader.AddressOfEntryPoint;



	PIMAGE_SECTION_HEADER pSectionHeader = NULL;

	dwSectionCount = pNtHeader->FileHeader.NumberOfSections;

	pSectionHeader = GetSectionHeader(pNtHeader);


	if (dwOldEnterPoint > (pSectionHeader->VirtualAddress + pSectionHeader->Misc.VirtualSize))
	{
		DWORD* pd = (DWORD*)((BYTE*)m_lpBaseAddress + pSectionHeader[dwSectionCount - 1].PointerToRawData);
		if (!memcmp(pd, start, 35)) {
			return true;
		}
		return false;
	}


	//for (DWORD nIndex = 0; nIndex < dwSectionCount; nIndex++)
	//{
	//	szWormSectionName = (char*)pSectionHeader->Name;
	//	if (szWormSectionName == ".text" || szWormSectionName=="CODE")
	//	{
	//		
	//		if (dwOldEnterPoint > (pSectionHeader->VirtualAddress + pSectionHeader->Misc.VirtualSize))
	//		{
	//			DWORD* pd = (DWORD*)((BYTE*)m_lpBaseAddress + pSectionHeader[dwSectionCount-1].PointerToRawData);
	//			if (!memcmp(pd, start, 35)) {
	//				return true;
	//			}

	//		}
	//		return false;
	//	}
	//	++pSectionHeader;
	//}
	return false;
}

bool CScanEngine::Kill(LPVOID lpNtHeader)
{




	PIMAGE_NT_HEADERS pNtHeader = (PIMAGE_NT_HEADERS)lpNtHeader;
	PIMAGE_SECTION_HEADER pSectionHeader = NULL;
	PIMAGE_OPTIONAL_HEADER pOptionalHeader = NULL;
	PIMAGE_FILE_HEADER pFileHeader = NULL;
//	DWORD dwFileAlignMent = 0;		// �ļ��������
	DWORD dwSectionAlignMent = 0;	// �ڴ����������л���
	DWORD dwSectionCount = 0;		// ��������
	DWORD dwImageBase = 0;			// ӳ���ļ������ڴ�Ļ�ַ
	DWORD dwWorm_RawDataSize = 0;	// ����������εĴ�С
	DWORD dwWorm_PointRawData = 0;	// ������ݵ��ļ�ƫ��
	DWORD dwJMPPoint = 0;			// JMP����ʵ��ڵ����ĵ�ַ
	DWORD dwJMPData = 0;			// JMP��ֵ
	DWORD dwOldEnterPoint = 0;		// ����޸ĵ���ڵ�
	DWORD dwEnterPoint = 0;			// ��ʵ����ڵ�
	DWORD dwImageSize = 0;			// �������ڴ�ʱ�����ڴ��С

//	dwFileAlignMent = pNtHeader->OptionalHeader.FileAlignment;
	dwSectionAlignMent = pNtHeader->OptionalHeader.SectionAlignment;
	dwSectionCount = pNtHeader->FileHeader.NumberOfSections;
	dwImageBase = pNtHeader->OptionalHeader.ImageBase;
	dwImageSize = pNtHeader->OptionalHeader.SizeOfImage;
	dwOldEnterPoint = pNtHeader->OptionalHeader.AddressOfEntryPoint;

	pSectionHeader = GetSectionHeader(pNtHeader);


	dwJMPData = *(DWORD*)((BYTE*)m_lpBaseAddress + pSectionHeader[dwSectionCount - 1].PointerToRawData+ WORM_ENTER_POINT_ADDRESS_OFFS+3);
	dwJMPPoint = dwImageBase + dwOldEnterPoint + 0x26C;
	dwEnterPoint = dwJMPData + dwJMPPoint + 5- dwImageBase;

	dwWorm_RawDataSize = pSectionHeader[dwSectionCount - 1].SizeOfRawData;
	m_dwWorm_RawDataSize = dwWorm_RawDataSize;
	
	// �޸���ڵ�
	pNtHeader->OptionalHeader.AddressOfEntryPoint = dwEnterPoint;
	// �޸����θ���
	pNtHeader->FileHeader.NumberOfSections--;
	// �޸��ļ�ImageSize
	dwImageSize = dwImageSize - Align(dwWorm_RawDataSize, dwSectionAlignMent);
	pNtHeader->OptionalHeader.SizeOfImage = dwImageSize;
	// ������������Ϣ
	memset(&pSectionHeader[dwSectionCount - 1], 0, sizeof(IMAGE_SECTION_HEADER));

	return true;

	//string szWormSectionName = "";
	//for (DWORD nIndex = 0; nIndex < dwSectionCount; nIndex++)
	//{
	//	szWormSectionName = (char*)pSectionHeader->Name;
	//	if (szWormSectionName == WORM_FLAG)
	//	{
	//		// �ҵ��������EXE�ļ��е����Σ���ȡ���ε��е���Ϣ
	//		dwWorm_RawDataSize = pSectionHeader->SizeOfRawData;
	//		m_dwWorm_RawDataSize = dwWorm_RawDataSize;
	//		dwWorm_PointRawData = pSectionHeader->PointerToRawData;
	//		// ��ȡ��ʵ��ڵ�
	//		dwJMPData = (DWORD)*(DWORD*)((BYTE*)m_lpBaseAddress + dwWorm_PointRawData + WORM_ENTER_POINT_ADDRESS_OFFS + 1);
	//		dwJMPPoint = dwImageBase + dwOldEnterPoint + WORM_ENTER_POINT_ADDRESS_OFFS;
	//		dwJMPData = (~dwJMPData) + 1;
	//		dwEnterPoint = dwJMPPoint - dwJMPData + 5 - dwImageBase;
	//		// �޸���ڵ�
	//		pNtHeader->OptionalHeader.AddressOfEntryPoint = dwEnterPoint;
	//		// �޸����θ���
	//		pNtHeader->FileHeader.NumberOfSections--;
	//		// �޸��ļ�ImageSize
	//		dwImageSize = dwImageSize - Align(dwWorm_RawDataSize, dwSectionAlignMent);
	//		pNtHeader->OptionalHeader.SizeOfImage = dwImageSize;
	//		// ������������Ϣ
	//		memset(pSectionHeader, 0, sizeof(IMAGE_SECTION_HEADER));
	//		return true;
	//	}
	//	++pSectionHeader;
	//}

	return false;
}